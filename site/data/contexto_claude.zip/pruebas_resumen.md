# Resumen de pruebas

## P013 · POC v1 · error
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 148 · neto $-3934.44 · p vs RAND 0.5804 · Topstep 12.0% · aciertos 20.9% · factor 0.89 · peor drawdown $-7431.8
- causa: umbral de orden grande mal calculado (percentil truncado y sobre todas las órdenes: 15 contratos). Ver strategies/v1_aclaraciones.json
- notas: Corrida con la interpretación literal de la v1 (p99 de todas las órdenes = 15 contratos) y percentil truncado. No cuenta ni a favor ni en contra.

## P002 · BIG v1 · superada
- fecha 2026-10-22 · estudio tanda1
- operaciones 127 · neto $-2120.06 · p vs RAND 0.4086 · Topstep 0.0% · aciertos 30.7% · factor 0.81 · peor drawdown $-2893.48
- causa: pierde con costos base; no gana a RAND (p=0.4086); muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: Población corregida (órdenes de 10+ contratos, p99 ≈ 100). Seguir a la orden grande pierde: el mapa de señales muestra que esas órdenes marcan el peor momento de su media hora.

## P003 · ABS v1 · superada
- fecha 2026-10-22 · estudio tanda1
- operaciones 128 · neto $4641.16 · p vs RAND 0.002 · Topstep 6.4% · aciertos 42.2% · factor 1.38 · peor drawdown $-2093.64
- causa: pierde en 2025 (−$405); pasa Topstep solo 6.4% (128 operaciones en 576 sesiones no alcanzan la meta); 67.7% de la ganancia viene de 5 días
- notas: Única estrategia de la tanda 1 con ventaja real sobre el azar (p 0.002, sobrevive 2 ticks por lado, 12/15 caminos CPCV positivos). Revisión de código del Red Team: sin fuga de futuro; el placebo desplazado gana más porque el valor está en el nivel y la dirección, no en el momento. La fila confirm_s de la sensibilidad no vale (parámetro no conectado en el código v1). No pasa: pierde en 2025 y solo 6.4% de las cuentas Topstep llegan a la meta con 128 operaciones en 576 sesiones.

## P004 · POC v1 · superada
- fecha 2026-10-22 · estudio tanda1
- operaciones 148 · neto $-3934.44 · p vs RAND 0.5794 · Topstep 12.0% · aciertos 20.9% · factor 0.89 · peor drawdown $-7416.8
- causa: pierde con costos base; no gana a RAND (p=0.5794); muere con costos al doble; pierde en 2024, 2026; pasa Topstep solo 12.0%
- notas: Rechazo del área de valor hacia el POC en días que abren dentro del valor. El mapa confirma que el precio sale del valor más de lo que rebota.

## P005 · ABS v2 · superada
- fecha 2026-10-23 · estudio tanda2
- operaciones 126 · neto $8868.72 · p vs RAND 0.003 · Topstep 43.5% · aciertos 27.8% · factor 1.59 · peor drawdown $-2080.72
- causa: pasa Topstep solo 43.5% (umbral 50%); 72% de la ganancia viene de 5 días; ganancia concentrada en 2024 (2025 +$140, 2026 −$159)
- notas: ABS v2 (dejar correr al ganador, objetivo 40 puntos). La mejor hasta ahora: p 0.003, sobrevive costos al doble, 14/15 caminos CPCV, 43.5% de cuentas Topstep (RAND 3.5%). No pasa por tres cosas: Topstep bajo 50%, 72% de la ganancia en 5 días, y casi toda en 2024 (2025 +$140). Revisión de código: sin fuga; el placebo desplazado gana el triple porque el valor está en el nivel, no en el momento. ABS tiene una versión más; no gastarla hasta entender por qué 2025 no funciona.

## P006 · HVN v1 · superada
- fecha 2026-10-23 · estudio tanda2
- operaciones 1460 · neto $-30238.8 · p vs RAND 0.5624 · Topstep 0.0% · aciertos 33.2% · factor 0.55 · peor drawdown $-30238.8
- causa: pierde con costos base; no gana a RAND (p=0.5624); muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: HVN v1. Muere de forma contundente (0/15 CPCV, pierde los tres años). El mapa v3 lo explica: desde precios operables el precio no rebota en los nodos de ayer (−11.8 ticks a 15 min); el rebote del mapa v2 era un artefacto de medición.

## P007 · BIG v2 · superada
- fecha 2026-10-24 · estudio tanda3
- operaciones 2724 · neto $-72186.72 · p vs RAND 0.8052 · Topstep 0.0% · aciertos 43.0% · factor 0.48 · peor drawdown $-72186.72
- causa: pierde con costos base; no gana a RAND (p=0.8052); muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P008 · ORB v1 · superada
- fecha 2026-10-24 · estudio tanda3
- operaciones 743 · neto $-15143.54 · p vs RAND 0.5005 · Topstep 0.0% · aciertos 41.5% · factor 0.61 · peor drawdown $-15982.82
- causa: pierde con costos base; no gana a RAND (p=0.5005); muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P009 · ORB v1 · no_pasa
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 743 · neto $-19063.54 · p vs RAND 0.5455 · Topstep 0.0% · aciertos 40.5% · factor 0.55 · peor drawdown $-19456.6
- causa: pierde con costos base; no gana a RAND (p=0.5455); no gana a RAND2 con las mismas salidas (p=0.5614); DSR 0.0 < 0.95 con 552 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P010 · BIG v2 · no_pasa
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 2715 · neto $-102617.7 · p vs RAND 0.95 · Topstep 0.0% · aciertos 40.7% · factor 0.38 · peor drawdown $-102617.7
- causa: pierde con costos base; no gana a RAND (p=0.95); no gana a RAND2 con las mismas salidas (p=0.9391); DSR 0.0 < 0.95 con 569 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P011 · HVN v1 · no_pasa
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 1458 · neto $-87676.24 · p vs RAND 0.999 · Topstep 0.0% · aciertos 33.1% · factor 0.3 · peor drawdown $-87676.24
- causa: pierde con costos base; no gana a RAND (p=0.999); no gana a RAND2 con las mismas salidas (p=1.0); DSR 0.0 < 0.95 con 584 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P012 · ABS v2 · revisar
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 126 · neto $7873.72 · p vs RAND 0.005 · Topstep 41.4% · aciertos 27.0% · factor 1.52 · peor drawdown $-2095.72
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.0 < 0.95 con 601 intentos; 80.9% de la ganancia en 5 días; pierde en 2026; pasa Topstep solo 41.4%
- notas: 

## P014 · ABS v1 · revisar
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 127 · neto $4319.94 · p vs RAND 0.003 · Topstep 3.7% · aciertos 41.7% · factor 1.35 · peor drawdown $-1623.64
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.0 < 0.95 con 634 intentos; 65.9% de la ganancia en 5 días; pasa Topstep solo 3.7%
- notas: 

## P015 · BIG v1 · no_pasa
- fecha 2026-10-24 · estudio repeticion_1_1
- operaciones 127 · neto $-2235.06 · p vs RAND 0.4845 · Topstep 0.0% · aciertos 30.7% · factor 0.8 · peor drawdown $-3008.48
- causa: pierde con costos base; no gana a RAND (p=0.4845); no gana a RAND2 con las mismas salidas (p=0.4675); DSR 0.0 < 0.95 con 651 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P016 · ABS v3 · revisar
- fecha 2026-10-25 · estudio abs_v3
- operaciones 143 · neto $4404.46 · p vs RAND 0.0539 · Topstep 13.9% · aciertos 22.4% · factor 1.24 · peor drawdown $-1756.58
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: no gana a RAND (p=0.0539); no gana a RAND2 con las mismas salidas (p=0.0679); DSR 0.0 < 0.95 con 668 intentos; 108.5% de la ganancia en 5 días; pasa Topstep solo 13.9%
- notas: 

## P017 · ACC v1 · revisar
- fecha 2026-10-25 · estudio aceptacion_v1
- operaciones 97 · neto $2028.34 · p vs RAND 0.1928 · Topstep 0.0% · aciertos 17.5% · factor 1.16 · peor drawdown $-2555.96
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: 97 operaciones / 556 sesiones: por debajo del mínimo
- notas: 

## P018 · SMT v1 · no_pasa
- fecha 2026-10-25 · estudio smt_v1
- operaciones 1353 · neto $-67444.34 · p vs RAND 0.958 · Topstep 1.2% · aciertos 5.9% · factor 0.53 · peor drawdown $-67444.34
- causa: pierde con costos base; no gana a RAND (p=0.958); no gana a RAND2 con las mismas salidas (p=0.96); DSR 0.0 < 0.95 con 698 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 1.2%
- notas: 

## P019 · VAR v1 · no_pasa
- fecha 2026-10-25 · estudio regla80_v1
- operaciones 113 · neto $-7947.14 · p vs RAND 0.8911 · Topstep 0.0% · aciertos 10.6% · factor 0.53 · peor drawdown $-8950.08
- causa: pierde con costos base; no gana a RAND (p=0.8911); no gana a RAND2 con las mismas salidas (p=0.9131); DSR 0.0 < 0.95 con 714 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P020 · ACC v2 · revisar
- fecha 2026-10-25 · estudio aceptacion_v2
- operaciones 91 · neto $4346.02 · p vs RAND 0.1209 · Topstep 0.0% · aciertos 19.8% · factor 1.38 · peor drawdown $-2191.7
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: 91 operaciones / 556 sesiones: por debajo del mínimo
- notas: 

## P021 · ABI v1 · revisar
- fecha 2026-10-25 · estudio abi_v1
- operaciones 120 · neto $7261.4 · p vs RAND 0.045 · Topstep 23.0% · aciertos 11.7% · factor 1.42 · peor drawdown $-6698.62
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.0 < 0.95 con 743 intentos; 206.4% de la ganancia en 5 días; pierde en 2024, 2026; pasa Topstep solo 23.0%
- notas: 

## P022 · ABV v1 · revisar
- fecha 2026-10-25 · estudio abv_v1
- operaciones 126 · neto $1818.72 · p vs RAND 0.1648 · Topstep 12.2% · aciertos 9.5% · factor 1.1 · peor drawdown $-9930.08
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: no gana a RAND (p=0.1648); no gana a RAND2 con las mismas salidas (p=0.1948); DSR 0.0 < 0.95 con 760 intentos; 796.5% de la ganancia en 5 días; muere con costos al doble; pierde en 2024, 2026; pasa Topstep solo 12.2%
- notas: 

## P023 · HVF v1 · revisar
- fecha 2026-10-25 · estudio hvf_v1
- operaciones 107 · neto $535.54 · p vs RAND 0.2607 · Topstep 4.4% · aciertos 13.1% · factor 1.03 · peor drawdown $-5305.94
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: no gana a RAND (p=0.2607); no gana a RAND2 con las mismas salidas (p=0.3956); DSR 0.0 < 0.95 con 777 intentos; 1780.7% de la ganancia en 5 días; muere con costos al doble; pierde en 2025; pasa Topstep solo 4.4%
- notas: 

## P024 · ABK v1 · no_pasa
- fecha 2026-10-25 · estudio abk_v1
- operaciones 694 · neto $-36133.32 · p vs RAND 0.5574 · Topstep 8.7% · aciertos 12.5% · factor 0.73 · peor drawdown $-39781.02
- causa: pierde con costos base; no gana a RAND (p=0.5574); no gana a RAND2 con las mismas salidas (p=0.7812); DSR 0.0 < 0.95 con 794 intentos; muere con costos al doble; pierde en 2024, 2026; pasa Topstep solo 8.7%
- notas: 

## P025 · LVN v1 · no_pasa
- fecha 2026-10-25 · estudio lvn_v1
- operaciones 381 · neto $-8670.18 · p vs RAND 0.6763 · Topstep 0.0% · aciertos 19.7% · factor 0.53 · peor drawdown $-8887.38
- causa: pierde con costos base; no gana a RAND (p=0.6763); no gana a RAND2 con las mismas salidas (p=0.6374); DSR 0.0 < 0.95 con 810 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P026 · ABI v2 · no_pasa
- fecha 2026-10-25 · estudio abi_v2
- operaciones 132 · neto $-1123.96 · p vs RAND 0.3606 · Topstep 0.0% · aciertos 18.9% · factor 0.93 · peor drawdown $-7055.92
- causa: pierde con costos base; no gana a RAND (p=0.3606); no gana a RAND2 con las mismas salidas (p=0.3057); DSR 0.0 < 0.95 con 825 intentos; muere con costos al doble; pierde en 2024, 2025; pasa Topstep solo 0.0%
- notas: 

## P027 · ABD v1 · revisar
- fecha 2026-10-25 · estudio abd_v1
- operaciones 111 · neto $5720.42 · p vs RAND 0.001 · Topstep 0.0% · aciertos 45.0% · factor 1.6 · peor drawdown $-1375.36
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.001 < 0.95 con 842 intentos; 57.8% de la ganancia en 5 días; pasa Topstep solo 0.0%
- notas: 

## P028 · VBR v1 · no_pasa
- fecha 2026-10-25 · estudio vbr_v1
- operaciones 658 · neto $-33702.24 · p vs RAND 1.0 · Topstep 0.0% · aciertos 19.3% · factor 0.58 · peor drawdown $-35618.0
- causa: pierde con costos base; no gana a RAND (p=1.0); no gana a RAND2 con las mismas salidas (p=0.998); DSR 0.0 < 0.95 con 859 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P029 · IMB v1 · no_pasa
- fecha 2026-10-25 · estudio imb_v1
- operaciones 2607 · neto $-23784.46 · p vs RAND 0.001 · Topstep 0.0% · aciertos 32.8% · factor 0.81 · peor drawdown $-24285.58
- causa: pierde con costos base; DSR 0.0 < 0.95 con 876 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P030 · ABU v1 · revisar
- fecha 2026-10-25 · estudio abu_v1
- operaciones 181 · neto $5955.82 · p vs RAND 0.001 · Topstep 9.9% · aciertos 40.9% · factor 1.36 · peor drawdown $-1355.84
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.0 < 0.95 con 893 intentos; 69.1% de la ganancia en 5 días; pasa Topstep solo 9.9%
- notas: 

## P031 · ABU v2 · revisar
- fecha 2026-10-25 · estudio abu_v2
- operaciones 181 · neto $11911.64 · p vs RAND 0.001 · Topstep 41.2% · aciertos 40.9% · factor 1.36 · peor drawdown $-2711.68
- causa: placebo desplazado sospechoso: revisión de código pendiente; además: DSR 0.0 < 0.95 con 910 intentos; 69.1% de la ganancia en 5 días; pasa Topstep solo 41.2%
- notas: 

## P032 · ABT v1 · no_pasa
- fecha 2026-10-25 · estudio abt_v1
- operaciones 128 · neto $-3588.84 · p vs RAND 0.7143 · Topstep 0.0% · aciertos 28.1% · factor 0.75 · peor drawdown $-5079.22
- causa: pierde con costos base; no gana a RAND (p=0.7143); no gana a RAND2 con las mismas salidas (p=0.7093); DSR 0.0 < 0.95 con 927 intentos; muere con costos al doble; pierde en 2024, 2025; pasa Topstep solo 0.0%
- notas: 

## P033 · ABQ v1 · no_pasa
- fecha 2026-10-25 · estudio abq_v1
- operaciones 167 · neto $-1961.26 · p vs RAND 0.2428 · Topstep 0.0% · aciertos 31.1% · factor 0.83 · peor drawdown $-2943.12
- causa: pierde con costos base; no gana a RAND (p=0.2428); no gana a RAND2 con las mismas salidas (p=0.2527); DSR 0.0 < 0.95 con 944 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P034 · DVG v1 · no_pasa
- fecha 2026-10-25 · estudio dvg_v1
- operaciones 1296 · neto $-57138.88 · p vs RAND 0.998 · Topstep 0.0% · aciertos 27.5% · factor 0.53 · peor drawdown $-57138.88
- causa: pierde con costos base; no gana a RAND (p=0.998); no gana a RAND2 con las mismas salidas (p=1.0); DSR 0.0 < 0.95 con 961 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 

## P035 · FAF v1 · no_pasa
- fecha 2026-10-25 · estudio faf_v1
- operaciones 396 · neto $-50476.88 · p vs RAND 1.0 · Topstep 0.0% · aciertos 27.5% · factor 0.4 · peor drawdown $-51289.2
- causa: pierde con costos base; no gana a RAND (p=1.0); no gana a RAND2 con las mismas salidas (p=1.0); DSR 0.0 < 0.95 con 974 intentos; muere con costos al doble; pierde en 2024, 2025, 2026; pasa Topstep solo 0.0%
- notas: 
