# Revisión ciega · P005 · ABS v2 · 24 de octubre de 2026

Revisor: Claude sin contexto del proyecto (conversación nueva, solo el paquete `results/P005/redteam/`). Veredicto del revisor: **No confío**. Respuesta del laboratorio: **el revisor tiene razón en lo esencial**. Acciones tomadas el mismo día.

## Respuesta por hallazgo

| # | Hallazgo del revisor | ¿Correcto? | Qué se hizo |
|---|---|---|---|
| 1 | Falta el código v1 que genera las señales ABS; no se puede auditar la fuga | **Sí (empaquetado)** | El paquete ahora lleva el motor completo (`engine/`), registro, sesiones con exclusiones, huellas de datos, recibos y Dockerfile. |
| 2 | Placebo adelantado gana 3× y la sospecha sigue abierta | **Sí** | Con el motor completo la revisión es posible; la revisión interna no encontró fuga. Queda abierta hasta una segunda revisión ciega sobre el paquete completo. |
| 3 | `pooled_quantile` puede dar percentiles equivocados (prueba sintética: verdadero 100, calculado 1) | **Sí** | Ahora se guardan TODOS los valores por sesión y el percentil es exacto; el programa falla si falta alguno. Umbrales de todas las pruebas cambian → repetición. |
| 4 | Objetivo cobrado en el mismo llenado de entrada (22/02/2024 09:48:30, MFE/MAE ±179, 0 s) | **Sí, y peor**: el libro de ATAS estuvo congelado en 71582/71584 mientras se operaba en 71762–71778 | Entrada = peor entre cotización previa y primer precio operado; el llenado de entrada no cuenta para objetivo/stop; se cuentan las cotizaciones anómalas. Prueba unitaria nueva. |
| 5 | Stops llenados al precio del stop aunque el mercado salte más allá | **Sí** | Stop = peor entre el precio del stop y el precio real del llenado que lo disparó. Prueba unitaria actualizada (−8 ticks en vez de −6 en el caso de salto). |
| 6 | La regla `through` no valida profundidad ni cola; 27 objetivos de $796 deciden el resultado | **Sí (limitación declarada)** | Se mantiene como límite conocido para 1 contrato; a 5 contratos no está validado y la página lo dice. La sensibilidad "10 objetivos menos → negativo" se publica. |
| 7 | Integridad de fechas OK; neutralidad y examen sellado no demostrables con el paquete | **Sí (empaquetado)** | `sessions_manifest.json` (congelado el 22/10, antes de cualquier prueba, con cada exclusión) va en el paquete; el examen sellado sigue cifrado con la llave fuera de la VM. La selección de ABS v2 fue en muestra (estudio de salidas): es verdad y está escrito. |
| 8 | DSR 0.001 < 0.95 y largo mínimo 8.35 años > 2.3: el protocolo propio desaprueba | **Sí** | El veredicto ahora aplica DSR ≥ 0.95 como criterio (estaba escrito, no implementado). El registro completo (295 intentos entonces, 341 hoy) va en el paquete. |
| 9 | 71.8% en 5 días; sin los 10 mejores días el neto es negativo; 2025–2026 combinados −$20 | **Sí** | Ya era causa de no-pasa; se agrega al texto de causa de forma automática. |
| 10 | Comisión correcta; deslizamiento es supuesto; 5 contratos no validados | **Sí** | Se mantiene el escenario a 5 contratos como información, no veredicto; se añade a limitaciones. |
| 11 | No reproducible con el paquete; dos identificadores de commit; semilla descrita distinto | **Sí (empaquetado y texto)** | Dockerfile, recibos con huellas de las dos corridas, un solo campo de commit, y el protocolo v3 describe la semilla real `SHA-256(id:fecha:k)`. La cinta (3.3 GB) no viaja: sus huellas sí. |
| 12 | Topstep 43.5% < 50% y largo mínimo: "revisar" ocultaba las otras fallas | **Sí** | La causa de "revisar" ahora lista todos los criterios incumplidos. P005 ya había sido corregida a no-pasa; el paquete llevaba la ficha sin la corrección → las correcciones ahora se escriben también en `results/<id>/report.json`. |
| 13 | RAND no copia las salidas; p=0.0066 no sale de 1,000 corridas; CPCV no valida la selección | **Sí** | RAND2 (mismas salidas) como control adicional; estrés con 1,000 corridas (0.0066 era 2/301 con 300); CPCV queda declarado como estabilidad temporal, no validación de selección. |
| 14 | La regla describe la salida como "por tiempo"; en realidad 90 stops, 27 objetivos, 9 tiempo | **Sí** | `strategies/v2_aclaraciones.json` (sellada): ABS v2 es pocos aciertos con objetivos grandes; mi narrativa era falsa. |

## Consecuencia

El motor 1.0 tenía llenados optimistas. **Toda prueba corrida con él (P002–P008) queda marcada "superada" y se repite con el motor 1.1** bajo el protocolo v3 (los intentos cuentan igual). El mapa de señales no usa el simulador, pero sus umbrales de órdenes y absorción cambian con los percentiles exactos: se repite como mapa v4. El estudio de salidas se repite como `salidas_1_1`.

Lo que sigue abierto: una segunda revisión ciega con el paquete completo sobre la repetición de ABS v2, y la validación de deslizamiento y capacidad a más de 1 contrato (requiere datos de ejecución real, no de cinta).

## Texto íntegro del revisor

(ver `P005_revisor.md` en esta misma carpeta)
