# Laboratorio NQ · Informe de avance · 24 de octubre de 2026

Para: Jose Miguel y Oscar. Preparado por Claude (Fable 5.1). Página: https://cryptobot-liga.vercel.app · Estado en una página: https://github.com/josemiguelw7/cryptobot/blob/main/LAB.md · Decisiones con fecha: https://github.com/josemiguelw7/cryptobot/blob/main/docs/decisions.md

## 1. Qué es el laboratorio y qué pregunta responde

Un sistema que prueba, con método y sin engañarse, si alguna estrategia de order flow en el futuro NQ le gana al azar después de costos y pasaría una cuenta Topstep $50K. No toca dinero real. Todo lo que se prueba queda escrito antes de probarse, todo lo que se corre queda registrado (también lo que falla), y los resultados se publican completos.

## 2. Datos

- 727 sesiones de NQ (2 de enero de 2024 a 22 de octubre de 2026), 197 millones de operaciones individuales con su libro de órdenes, descargadas de ATAS vía Rithmic y validadas contra Databento.
- **576 sesiones válidas de diseño** (hasta el 21 de abril de 2026) tras una auditoría de huecos, rollos y horario de verano. 19 excluidas con motivo escrito.
- **Examen final sellado**: 132 sesiones desde el 22 de abril de 2026, cifradas. Se abre una sola vez, con una estrategia que el comité apruebe.
- En camino: ES y YM (descargándose en la laptop de Jose Miguel) para el chequeo cruzado entre mercados.

## 3. Reglas fijas (verificadas, no supuestas)

- Costos: comisión Topstep NQ **$3.78 por ida y vuelta** (verificado en el centro de ayuda de Topstep el 22/10/2026) más 1 tick de deslizamiento por lado = $13.78 por operación. Prueba de estrés con 2 ticks.
- Cuenta Topstep $50K: meta $3,000; pérdida máxima $2,000 que sube con el balance al cierre y se vigila en tiempo real; límite diario $1,000; 5 contratos; consistencia 50% (el laboratorio es más estricto que el 55% oficial).
- Horario: Nueva York 09:30–11:30 ET, cierre forzado 11:45; máximo 6 operaciones por día; parar tras 3 pérdidas seguidas.

## 4. Cómo se decide si una estrategia sirve (protocolo v2)

Para pasar, una estrategia debe cumplir las cuatro: (1) ganar a un bot aleatorio emparejado (misma cantidad, duración y horario de operaciones, 1,000 corridas, p ≤ 0.05); (2) seguir ganando con costos al doble; (3) ganar en 2024, 2025 y 2026; (4) pasar la cuenta Topstep en al menos 50% de los arranques (una cuenta nueva cada sesión). Además: mínimo 100 operaciones y 120 sesiones, placebos (señal desplazada, direcciones barajadas), curva de costos 0–4 ticks, sensibilidad de cada parámetro (se busca una meseta, no la mejor celda), 15 caminos de validación cruzada, resultados por año y por régimen de mercado, y un Sharpe deflactado que descuenta **todos** los intentos registrados.

## 5. Infraestructura (lo que corre solo)

- **Motor de pruebas** determinista: simula cada operación contra la cinta real con llenados conservadores (el objetivo solo se da por llenado si la cinta pasa de largo; el stop lleva deslizamiento; entrada con el libro que ve el siguiente llenado).
- **Registro de intentos** de solo agregar, con cadena de huellas: cada línea lleva el SHA-256 de la anterior; borrar o editar rompe la cadena. Hoy: **341 intentos**, cadena intacta.
- **Orquestador**: cada 15 minutos toma la siguiente prueba congelada y la corre dos veces en contenedores efímeros (sin red, datos en solo lectura, clon limpio del commit exacto); publica solo si el resultado se reproduce bit a bit. Antes de cada prueba verifica la prueba dorada (el motor da siempre la misma huella) y las huellas de los datos.
- **Publicación automática** desde el servidor a GitHub y Vercel cada 30 minutos; **avisos por correo** a los dos al terminar cada prueba.
- **Documentos congelados** con huella SHA-256 y sello OpenTimestamps (prueba externa de fecha): reglas de cada estrategia, protocolo, lista de sesiones, costos, reglas Topstep.
- **Red Team**: automático en cada prueba, y una revisión ciega por un Claude sin contexto para toda prueba que pase o quede en revisión.

## 6. Resultados hasta hoy

| Prueba | Qué | Veredicto | Neto | p vs azar | Topstep | Causa |
|---|---|---|---|---|---|---|
| P002 | BIG v1 · seguir órdenes grandes con confirmación y nivel | no pasa | −$2,120 | 0.41 | 0% | no gana al azar |
| P003 | ABS v1 · absorción en nivel | no pasa | +$4,641 | 0.002 | 6.4% | pierde 2025; muy pocas operaciones (128) |
| P004 | POC v1 · rechazo del área de valor | no pasa | −$3,934 | 0.58 | 12% | no gana al azar |
| P005 | ABS v2 · dejar correr al ganador | no pasa | +$8,869 | 0.003 | **43.5%** | 72% de la ganancia en 5 días; casi toda en 2024 |
| P006 | HVN v1 · rechazo de nodos de ayer | no pasa | −$30,239 | 0.56 | 0% | la premisa era un artefacto de medición |
| P013 | BIG v1 (umbral mal calculado) | error | — | — | — | no cuenta |

**Lo más cerca**: ABS v2. Gana al azar con claridad, sobrevive costos al doble, 14 de 15 caminos de validación positivos, 43.5% de cuentas Topstep contra 3.5% del azar. Falla porque su ganancia depende de 5 días y de 2024. A ABS le queda una versión; no la gastamos hasta entender por qué 2025 no funciona.

**Estudio de salidas (pedido de Oscar)**: 159 combinaciones de take profit, stop, tiempo y piramidar sobre las mismas señales. Hallazgos: en ABS, dejar correr al ganador 15 minutos sube de +$4.6k a +$9.9k (es lo que se convirtió en ABS v2); stops de 3–4 puntos la matan; piramidar la perjudica (es reversión, no tendencia). BIG y POC no tienen meseta.

**Mapa de señales (versión 3, 5,000 sorteos por evento, precios operables)**: de 12 señales, la más firme es **seguir a la orden grande**: después de una orden agresiva grande el precio sigue +12 ticks a 5, 15 y 30 minutos, estable en 2024 y 2025, en días de tendencia (+19) y de balance (+5). Absorción: +8 ticks a 30 min pero no estable entre años. Ruptura del rango inicial: +18 ticks a 30 min, estable. Las demás, cerca de cero.

**Proxy de régimen**: a las 09:45 no se puede anticipar si el día será de tendencia o balance (base 48%, mejor proxy 57%). La partición por régimen sirve para entender, no para operar.

## 7. Errores que el sistema atrapó (y por eso existe)

1. El umbral de "orden grande" se calculaba sobre todas las órdenes (casi todas de 1 contrato): quedaba en 15 contratos. Corregido: órdenes de 10+ contratos.
2. Con 1,000 sorteos el mapa no podía declarar nada significativo por construcción. Corregido: 5,000.
3. El simulador entraba con el libro **anterior** a un barrido (una orden grande ejecuta todos sus llenados en el mismo instante). Corregido: entrada con el libro que ve el siguiente llenado.
4. El mapa medía desde el último llenado del barrido, ~8 ticks atrás del libro real: "desvanecer órdenes grandes" y "rebote en nodos de ayer" eran artefactos. Corregido: mapa v3 desde el mid del libro operable. Dos estrategias se descartaron antes de correr; una (HVN) ya había corrido y murió.
5. Un `push` pisó archivos de resultados; se reconstruyeron desde las fichas y el registro, y el flujo se corrigió.
Todo está en `decisions.md` con fecha.

## 8. En curso ahora mismo

- **BIG v2** (seguir a la orden grande con entrada inmediata, objetivo 12, stop 16) y **ORB v1** (ruptura del rango de los primeros 15 minutos): congeladas; el orquestador las corre solo. En el humo de 60 sesiones ambas pierden poco; el veredicto lo dan las 576.

## 9. Lo que necesitamos de Oscar

1. **Los ojos de Oscar**: hay dos muestras de 30 operaciones (ABS v1 y ABS v2) en la página › Pruebas › hoja completa › "Descargar muestra CSV". Marcar en cada fila "si/no" (¿la habría tomado?) y un comentario. El porcentaje de acuerdo entre el código y su criterio se publica; es la verificación que ningún estadístico puede hacer.
2. **7 preguntas** en la pestaña Estrategias (niveles del día anterior vs. día completo, qué es "grande", tiempo de confirmación, horario de tarde, stop habitual, validación del 27/02/2025 en ATAS, señales que falten).
3. Su lectura del mapa v3: ¿qué de lo que él ve en vivo coincide o no con "seguir a la orden grande" y con "ruptura del rango inicial"?

## 10. Siguientes pasos

1. Resultados de BIG v2 y ORB (hoy).
2. Revisión ciega de ABS v2 (Jose Miguel, conversación nueva de Claude; paquete listo).
3. ES y YM al servidor; chequeo cruzado como criterio adicional del comité.
4. Ventana viva: sesiones nuevas cada semana para medir, para siempre, en datos que nadie vio.
5. Comité: decidir la tanda 4 con el mapa v3 y las respuestas de Oscar.
